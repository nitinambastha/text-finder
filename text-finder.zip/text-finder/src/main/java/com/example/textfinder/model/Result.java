package com.example.textfinder.model;

public class Result {
  
  private String searchText;
  private Long numberOfOccurrences;
  
  /**
   * @return the searchText
   */
  public String getSearchText() {
    return searchText;
  }
  /**
   * @param searchText the searchText to set
   */
  public void setSearchText(String searchText) {
    this.searchText = searchText;
  }
  /**
   * @return the numberOfOccurrences
   */
  public Long getNumberOfOccurrences() {
    return numberOfOccurrences;
  }
  /**
   * @param numberOfOccurrences the numberOfOccurrences to set
   */
  public void setNumberOfOccurrences(Long numberOfOccurrences) {
    this.numberOfOccurrences = numberOfOccurrences;
  }
  
  

}
