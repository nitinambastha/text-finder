package com.example.textfinder.service;

import com.example.textfinder.model.Result;

public interface TextFinderService {
  
  public Result getNumberOfOccurrences(String text);

}
