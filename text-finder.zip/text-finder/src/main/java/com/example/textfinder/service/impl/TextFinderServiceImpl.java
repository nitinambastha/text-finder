package com.example.textfinder.service.impl;

import com.example.textfinder.model.Result;
import com.example.textfinder.service.TextFinderService;
import java.util.stream.Stream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class TextFinderServiceImpl implements TextFinderService {

  private static final Logger logger = LoggerFactory.getLogger(TextFinderServiceImpl.class);
  public static final String WHITESPACES = "[\\W]";

  /**
   * This method counts the number of occurrences of text received from user in the given string and
   * gives it back in response.
   */
  public Result getNumberOfOccurrences(String text) {
    var result = new Result();
    var sentence =
        "Nobody expects the Spanish Inquisition! Our chief weapon is surprise... surprise and fear... fear and surprise... our two weapons are fear and surprise... and ruthless efficiency... Our three weapons are fear, surprise, and ruthless efficiency..."
            + "and an almost fanatical devotion... Our four... no... amongst our weapons.... amongst our weaponry...are such elements as fear, surprise.... I'll come in again.";

    var count = Stream.of(sentence.split(WHITESPACES)).filter(c -> c.equalsIgnoreCase(text)).count();
    
    result.setSearchText(text);
    result.setNumberOfOccurrences(count);

    logger.info("Number of occurrences of {} in the given sentence is {}", text, count);
    return result;    
  }
}
