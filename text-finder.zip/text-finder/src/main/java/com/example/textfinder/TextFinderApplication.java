package com.example.textfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(TextFinderApplication.class, args);
	}

}
