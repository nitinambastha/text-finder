package com.example.textfinder.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.example.textfinder.service.impl.TextFinderServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TextFinderServiceImplTest {
  
  @InjectMocks
  TextFinderServiceImpl textFinderServiceImpl;
  
  @Test
  void TestGetNumberOfOccurrences() {
    var result = textFinderServiceImpl.getNumberOfOccurrences("our");
    assertEquals(6L, result.getNumberOfOccurrences());
  }

}
